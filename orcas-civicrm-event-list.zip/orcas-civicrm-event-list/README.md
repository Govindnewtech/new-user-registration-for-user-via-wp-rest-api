# CiviCRM Event List

## Description
Adds a shortcode to list CiviCRM events

## Usage
~~~
[civicrm-event-list]
~~~
Just drop the shortcode into any place where WordPress allows it (preferably pages) and you're good.
