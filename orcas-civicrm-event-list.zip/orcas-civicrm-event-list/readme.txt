=== CiviCRM Event List ===
Contributors: orcasdev
Tags: civicrm, event, list, eventlist, frontend, orcas
Requires at least: 4.9.2
Tested up to: 4.9.4
Requires PHP: 7.0.22
Stable tag: 0.2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description

Show all your Events managed with CiviCRM in your frontend.

We are not part of the CiviCRM-Team so we can not support CiviCRM related questions.


== Note ==

This Plugin is still alpha and work in progress.
So if something does not work properly leave a comment with your wordpress and your CiviCRM version.
We will try to fix issues as soon as possible.

You can also post suggestions for new Features.


== Installation ==

Copy the folder into you plugins folder and activate the Plugin in your Dashboard.


== Usage ==

You can use the Plugin with the shortcode
[civicrm-event-list]

== Change Notes ==

0.2.2

First Realease

0.2.3

Fixed warning, when plugin was activated
Only loads Events, when shortcode is rendered