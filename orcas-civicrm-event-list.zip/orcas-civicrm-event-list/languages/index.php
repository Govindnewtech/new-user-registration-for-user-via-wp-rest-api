<?php
//silence is golden